document.addEventListener("DOMContentLoaded", () => {

    const tabla = document.getElementById("detalleFactura");

    // Obtener carrito
    let carrito = JSON.parse(localStorage.getItem("miCarrito")) || [];

    let subtotalGeneral = 0;

    carrito.forEach(item => {
        const precio = Number(item.precio);
        const cantidad = Number(item.cantidad);
        const subtotal = precio * cantidad;
        subtotalGeneral += subtotal;

        const fila = `
            <tr>
                <td>${item.id}</td>
                <td colspan="2">${item.nombre}</td>
                <td>${cantidad}</td>
                <td>$${precio.toLocaleString()}</td>
                <td>$${subtotal.toLocaleString()}</td>
            </tr>
        `;
        tabla.insertAdjacentHTML("beforeend", fila);
    });

    // Totales
    const inputSubtotal = document.getElementById("subt");
    const inputIVA = document.getElementById("iva");
    const inputNeto = document.getElementById("neto");

    const iva = Math.round(subtotalGeneral * 0.19);
    const totalNeto = subtotalGeneral + iva;

    inputSubtotal.value = subtotalGeneral.toLocaleString();
    inputIVA.value = iva.toLocaleString();
    inputNeto.value = totalNeto.toLocaleString();

    // Generar factura
    const form = document.getElementById("formFactura");

    form.addEventListener("submit", (e) => {
        e.preventDefault();

        swal("Factura generada", "Gracias por su compra", "success");

        // Vaciar carrito
        localStorage.removeItem("miCarrito");
    });

});